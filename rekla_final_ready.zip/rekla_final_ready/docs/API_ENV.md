# إعداد مفتاح API

لا تكتب المفتاح داخل ملفات Dart ولا ترفعه إلى Git.

للاختبار المحلي:
```bash
flutter run --dart-define=API_FOOTBALL_KEY=YOUR_KEY
```

للإنتاج، استخدم Backend/Serverless Function يحتفظ بالمفتاح كـ Secret.
