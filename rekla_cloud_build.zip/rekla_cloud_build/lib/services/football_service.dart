
import '../models/models.dart';

class FootballService {
  static const demoMatches = <MatchItem>[
    MatchItem(id:1, home:'برشلونة', away:'ريال مدريد', time:'22:00', status:'مباشر', homeScore:2, awayScore:1,
      events:[
        MatchEvent("18'", "هدف", "لامين يامال", "تسديدة داخل المنطقة"),
        MatchEvent("41'", "هدف", "فينيسيوس", "هجمة مرتدة"),
        MatchEvent("67'", "هدف", "رافينيا", "ضربة رأسية"),
      ]),
    MatchItem(id:2, home:'مانشستر سيتي', away:'أرسنال', time:'20:30', status:'قادمة', homeScore:0, awayScore:0),
    MatchItem(id:3, home:'بايرن ميونخ', away:'دورتموند', time:'21:45', status:'قادمة', homeScore:0, awayScore:0),
    MatchItem(id:4, home:'إنتر ميلان', away:'ميلان', time:'19:00', status:'قادمة', homeScore:0, awayScore:0),
  ];

  static const standings = <StandingRow>[
    StandingRow(1,'برشلونة',10,25), StandingRow(2,'ريال مدريد',10,23),
    StandingRow(3,'أتلتيكو مدريد',10,21), StandingRow(4,'أتلتيك بلباو',10,18),
    StandingRow(5,'فالنسيا',10,16),
  ];

  static const news = <NewsItem>[
    NewsItem('أبرز مباريات اليوم والقنوات الناقلة','مباريات','منذ 20 دقيقة'),
    NewsItem('آخر أخبار الانتقالات في أوروبا','انتقالات','منذ ساعة'),
    NewsItem('تحديثات مهمة قبل الجولة القادمة','الدوريات','منذ ساعتين'),
    NewsItem('نجوم الأسبوع يتنافسون على جائزة الأفضل','جوائز','منذ 3 ساعات'),
  ];

  Future<List<MatchItem>> matches() async {
    await Future.delayed(const Duration(milliseconds: 450));
    return demoMatches;
  }
  Future<List<StandingRow>> standingsTable() async {
    await Future.delayed(const Duration(milliseconds: 250));
    return standings;
  }
  Future<List<NewsItem>> newsFeed() async {
    await Future.delayed(const Duration(milliseconds: 250));
    return news;
  }
}
