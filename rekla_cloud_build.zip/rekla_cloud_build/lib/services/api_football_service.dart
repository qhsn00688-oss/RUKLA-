
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/models.dart';

/// API-Football client.
/// For production, move this key to a backend/serverless function.
class ApiFootballService {
  static const baseUrl = 'https://v3.football.api-sports.io';
  final String apiKey;

  ApiFootballService({required this.apiKey});

  Future<Map<String, dynamic>> _get(
    String path, [
    Map<String, String> query = const {},
  ]) async {
    final uri = Uri.parse(baseUrl).replace(path: path, queryParameters: query);
    final response = await http.get(
      uri,
      headers: {'x-apisports-key': apiKey},
    );
    if (response.statusCode != 200) {
      throw Exception('API error ${response.statusCode}');
    }
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (body['errors'] is Map && (body['errors'] as Map).isNotEmpty) {
      throw Exception((body['errors'] as Map).values.join(', '));
    }
    return body;
  }

  Future<List<MatchItem>> liveMatches() async {
    final body = await _get('/fixtures', {'live': 'all'});
    final list = (body['response'] as List<dynamic>? ?? []);
    return list.map(_fixtureToMatch).toList();
  }

  Future<List<MatchItem>> matchesByDate(String date) async {
    final body = await _get('/fixtures', {'date': date});
    final list = (body['response'] as List<dynamic>? ?? []);
    return list.map(_fixtureToMatch).toList();
  }

  Future<Map<String, dynamic>> fixtureDetails(int fixtureId) async {
    final body = await _get('/fixtures', {'id': '$fixtureId'});
    final list = (body['response'] as List<dynamic>? ?? []);
    return list.isEmpty ? {} : list.first as Map<String, dynamic>;
  }

  Future<List<StandingRow>> standings({
    required int leagueId,
    required int season,
  }) async {
    final body = await _get('/standings', {
      'league': '$leagueId',
      'season': '$season',
    });
    final response = (body['response'] as List<dynamic>? ?? []);
    if (response.isEmpty) return [];
    final league = response.first as Map<String, dynamic>;
    final groups = (league['league']?['standings'] as List<dynamic>? ?? []);
    if (groups.isEmpty) return [];
    final rows = groups.first as List<dynamic>;
    return rows.map((e) {
      final x = e as Map<String, dynamic>;
      return StandingRow(
        (x['rank'] ?? 0) as int,
        (x['team']?['name'] ?? 'فريق').toString(),
        (x['all']?['played'] ?? 0) as int,
        (x['points'] ?? 0) as int,
      );
    }).toList();
  }

  MatchItem _fixtureToMatch(dynamic raw) {
    final x = raw as Map<String, dynamic>;
    final fixture = x['fixture'] as Map<String, dynamic>? ?? {};
    final teams = x['teams'] as Map<String, dynamic>? ?? {};
    final goals = x['goals'] as Map<String, dynamic>? ?? {};
    final status = fixture['status'] as Map<String, dynamic>? ?? {};
    return MatchItem(
      id: (fixture['id'] ?? 0) as int,
      home: (teams['home']?['name'] ?? 'المضيف').toString(),
      away: (teams['away']?['name'] ?? 'الضيف').toString(),
      time: (fixture['date'] ?? '').toString(),
      status: (status['short'] ?? 'NS').toString(),
      homeScore: (goals['home'] ?? 0) as int? ?? 0,
      awayScore: (goals['away'] ?? 0) as int? ?? 0,
    );
  }
}
