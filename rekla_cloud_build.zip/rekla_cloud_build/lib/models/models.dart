
class MatchEvent {
  final String minute, type, player, detail;
  const MatchEvent(this.minute, this.type, this.player, this.detail);
}
class MatchItem {
  final int id;
  final String home, away, time, status;
  final int homeScore, awayScore;
  final List<MatchEvent> events;
  const MatchItem({required this.id, required this.home, required this.away, required this.time,
    required this.status, required this.homeScore, required this.awayScore, this.events = const []});
}
class StandingRow {
  final int rank, played, points;
  final String team;
  const StandingRow(this.rank, this.team, this.played, this.points);
}
class NewsItem {
  final String title, category, time;
  const NewsItem(this.title, this.category, this.time);
}
