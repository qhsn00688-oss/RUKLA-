
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models/models.dart';
import 'services/football_service.dart';

const green = Color(0xFF18E37A);
const bg = Color(0xFF07131C);
const panel = Color(0xFF0D202B);

void main() => runApp(const ReklaApp());

class ReklaApp extends StatelessWidget {
  const ReklaApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner:false, title:'ركلة',
    theme: ThemeData(brightness:Brightness.dark, scaffoldBackgroundColor:bg,
      colorScheme:ColorScheme.fromSeed(seedColor:green,brightness:Brightness.dark),
      useMaterial3:true, fontFamily:'Arial'),
    home: const Root(),
  );
}

class Root extends StatefulWidget {
  const Root({super.key});
  @override State<Root> createState()=>_RootState();
}
class _RootState extends State<Root> {
  int tab=0;
  final pages=const [HomePage(), MatchesPage(), LeaguesPage(), NewsPage(), FavoritesPage()];
  @override Widget build(BuildContext c)=>Directionality(
    textDirection:TextDirection.rtl,
    child:Scaffold(
      appBar:AppBar(backgroundColor:bg, title:const Text('ركلة',style:TextStyle(fontWeight:FontWeight.w900)),
        actions:[IconButton(onPressed:()=>showSearch(context:context,delegate:TeamSearch()),icon:const Icon(Icons.search)),
          IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const SettingsPage())),icon:const Icon(Icons.settings_outlined))]),
      body:pages[tab],
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
        backgroundColor:panel,indicatorColor:green.withOpacity(.18),
        destinations:const [
          NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'الرئيسية'),
          NavigationDestination(icon:Icon(Icons.sports_soccer_outlined),selectedIcon:Icon(Icons.sports_soccer),label:'المباريات'),
          NavigationDestination(icon:Icon(Icons.emoji_events_outlined),selectedIcon:Icon(Icons.emoji_events),label:'الدوريات'),
          NavigationDestination(icon:Icon(Icons.article_outlined),selectedIcon:Icon(Icons.article),label:'الأخبار'),
          NavigationDestination(icon:Icon(Icons.star_border),selectedIcon:Icon(Icons.star),label:'المفضلة')]),
    ));
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
    Container(height:150,padding:const EdgeInsets.all(20),decoration:BoxDecoration(
      borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[Color(0xFF123B2A),Color(0xFF0B202C)])),
      child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('ركلة',style:TextStyle(fontSize:34,fontWeight:FontWeight.w900)),SizedBox(height:6),
        Text('كل كرة القدم في مكان واحد',style:TextStyle(fontSize:17)),Spacer(),
        Text('نتائج • مباريات • أخبار • ترتيب',style:TextStyle(color:green,fontWeight:FontWeight.bold))])),
    const SizedBox(height:22), const TitleRow('مباشر الآن'),
    const MatchTile(match:FootballService.demoMatches[0]),
    const SizedBox(height:18), const TitleRow('أهم مباريات اليوم'),
    ...FootballService.demoMatches.skip(1).map((m)=>MatchTile(match:m)),
    const SizedBox(height:18), const TitleRow('آخر الأخبار'),
    ...FootballService.news.take(2).map((n)=>NewsTile(item:n)),
  ]);
}

class MatchesPage extends StatefulWidget { const MatchesPage({super.key}); @override State<MatchesPage> createState()=>_MatchesPageState(); }
class _MatchesPageState extends State<MatchesPage>{
  final s=FootballService(); late Future<List<MatchItem>> f;
  @override void initState(){super.initState();f=s.matches();}
  @override Widget build(BuildContext c)=>FutureBuilder<List<MatchItem>>(future:f,builder:(c,x){
    if(x.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());
    return RefreshIndicator(onRefresh:()async{setState(()=>f=s.matches());await f;},
      child:ListView(padding:const EdgeInsets.all(16),children:[
        const TitleRow('المباريات'), ...((x.data??[]).map((m)=>MatchTile(match:m))) ]));
  });
}

class MatchTile extends StatelessWidget{
  final MatchItem match; const MatchTile({required this.match,super.key});
  @override Widget build(BuildContext c)=>Card(color:panel,margin:const EdgeInsets.only(bottom:10),
    child:InkWell(borderRadius:BorderRadius.circular(14),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>MatchDetails(match:match))),
      child:Padding(padding:const EdgeInsets.symmetric(vertical:14,horizontal:12),child:Row(
        mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
          Expanded(child:Text(match.home,textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.bold))),
          Column(children:[Text(match.status,style:TextStyle(color:match.status=='مباشر'?Colors.redAccent:green,fontSize:12)),
            const SizedBox(height:4),Text('${match.homeScore} - ${match.awayScore}',style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),
            Text(match.time,style:const TextStyle(color:Colors.white60))]),
          Expanded(child:Text(match.away,textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.bold))),
        ])));
}

class MatchDetails extends StatelessWidget{
  final MatchItem match; const MatchDetails({required this.match,super.key});
  @override Widget build(BuildContext c)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(
    appBar:AppBar(title:const Text('تفاصيل المباراة')),body:ListView(padding:const EdgeInsets.all(18),children:[
      Card(color:panel,child:Padding(padding:const EdgeInsets.all(22),child:Column(children:[
        Text(match.status,style:const TextStyle(color:green,fontWeight:FontWeight.bold)),const SizedBox(height:16),
        Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[
          Expanded(child:Text(match.home,textAlign:TextAlign.center,style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold))),
          Text('${match.homeScore} - ${match.awayScore}',style:const TextStyle(fontSize:28,fontWeight:FontWeight.w900)),
          Expanded(child:Text(match.away,textAlign:TextAlign.center,style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold))) ]))])),
      const SizedBox(height:18),const TitleRow('أحداث المباراة'),
      if(match.events.isEmpty) const Card(child:ListTile(title:Text('لا توجد أحداث مسجلة بعد')))
      else ...match.events.map((e)=>Card(color:panel,child:ListTile(leading:Text(e.minute,style:const TextStyle(color:green,fontWeight:FontWeight.bold)),
        title:Text('${e.type} • ${e.player}'),subtitle:Text(e.detail)))),
    ])));
}

class LeaguesPage extends StatelessWidget{
  const LeaguesPage({super.key});
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
    const TitleRow('ترتيب الدوري الإسباني'),
    Card(color:panel,child:Column(children:[
      const ListTile(title:Text('الفريق'),trailing:Text('نقاط')),
      ...FootballService.standings.map((r)=>ListTile(leading:CircleAvatar(radius:14,child:Text('${r.rank}')),title:Text(r.team),
        subtitle:Text('${r.played} مباريات'),trailing:Text('${r.points}',style:const TextStyle(fontWeight:FontWeight.w900,color:green))))])),
    const SizedBox(height:18),const TitleRow('البطولات'),
    ...['الدوري الإنجليزي الممتاز','الدوري الإسباني','الدوري الإيطالي','الدوري الألماني','دوري أبطال أوروبا']
      .map((x)=>Card(color:panel,child:ListTile(leading:const Icon(Icons.emoji_events_outlined,color:green),title:Text(x),trailing:const Icon(Icons.chevron_left))))
  ]);
}

class NewsPage extends StatelessWidget{
  const NewsPage({super.key});
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
    const TitleRow('آخر الأخبار'), ...FootballService.news.map((n)=>NewsTile(item:n))]);
}
class NewsTile extends StatelessWidget{
  final NewsItem item; const NewsTile({required this.item,super.key});
  @override Widget build(BuildContext c)=>Card(color:panel,margin:const EdgeInsets.only(bottom:10),
    child:ListTile(leading:const CircleAvatar(backgroundColor:green,child:Icon(Icons.article,color:Colors.black)),
      title:Text(item.title,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${item.category} • ${item.time}')));
}

class FavoritesPage extends StatelessWidget{
  const FavoritesPage({super.key});
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
    const TitleRow('فرقي المفضلة'),
    ...['برشلونة','ريال مدريد','مانشستر سيتي','ليفربول'].map((x)=>Card(color:panel,child:ListTile(
      leading:const Icon(Icons.shield_outlined,color:green),title:Text(x),trailing:IconButton(icon:const Icon(Icons.notifications_none),onPressed:(){}))))
  ]);
}

class SettingsPage extends StatefulWidget{const SettingsPage({super.key});@override State<SettingsPage>createState()=>_SettingsState();}
class _SettingsState extends State<SettingsPage>{
  bool notifications=true,dark=true;
  @override Widget build(BuildContext c)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:const Text('الإعدادات')),
    body:ListView(children:[
      SwitchListTile(value:notifications,onChanged:(v)=>setState(()=>notifications=v),title:const Text('إشعارات المباريات'),subtitle:const Text('الأهداف وبداية المباريات')),
      SwitchListTile(value:dark,onChanged:(v)=>setState(()=>dark=v),title:const Text('الوضع الداكن')),
      const ListTile(title:Text('اللغة'),subtitle:Text('العربية')),
      const ListTile(title:Text('الإصدار'),subtitle:Text('1.0.0')),
    ])));
}

class TeamSearch extends SearchDelegate<String>{
  final teams=['برشلونة','ريال مدريد','مانشستر سيتي','ليفربول','بايرن ميونخ','أرسنال'];
  @override List<Widget>? buildActions(BuildContext c)=>[IconButton(onPressed:()=>query='',icon:const Icon(Icons.clear))];
  @override Widget? buildLeading(BuildContext c)=>IconButton(onPressed:()=>close(c,''),icon:const Icon(Icons.arrow_back));
  @override Widget buildResults(BuildContext c)=>_results();
  @override Widget buildSuggestions(BuildContext c)=>_results();
  Widget _results()=>ListView(children:teams.where((x)=>x.contains(query)).map((x)=>ListTile(title:Text(x),leading:const Icon(Icons.shield_outlined,color:green))).toList());
}

class TitleRow extends StatelessWidget{final String t;const TitleRow(this.t,{super.key});@override Widget build(BuildContext c)=>Padding(
  padding:const EdgeInsets.only(bottom:10),child:Text(t,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)));}

class HomePageOld extends StatelessWidget{const HomePageOld({super.key});@override Widget build(BuildContext c)=>const SizedBox();}
