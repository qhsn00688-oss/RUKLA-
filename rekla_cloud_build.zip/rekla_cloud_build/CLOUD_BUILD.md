# ركلة — البناء السحابي

بما أنك لا تملك كمبيوتر، يمكن بناء نسخة Android في خدمة CI/CD سحابية.

## Android
المشروع يحتوي على GitHub Actions وCodemagic.

### GitHub Actions
1. ارفع المشروع إلى GitHub.
2. في إعدادات المستودع أضف Secret باسم:
   `API_FOOTBALL_KEY`
3. شغّل workflow:
   `Build Rekla Android`
4. نزّل ملف APK من Artifacts.

### Codemagic
يمكن استيراد المشروع وتشغيل `codemagic.yaml`.
ضع `API_FOOTBALL_KEY` كـ Secret داخل Codemagic.

## iPhone
بناء IPA يتطلب إعداد توقيع Apple Developer/Certificates، لذلك لا يمكن إصدار نسخة iPhone قابلة للتثبيت من دون إعداد حساب Apple والتوقيع.

## الأمان
لا تضع المفتاح داخل ملفات Dart أو Git. استخدم Secrets في خدمة البناء.
