# ركلة ⚽ — v1.1

نسخة Android + iPhone جاهزة للتطوير مع عميل API-Football فعلي.

## ما أضيف
- مباريات مباشرة: `/fixtures?live=all`
- مباريات حسب التاريخ
- تفاصيل مباراة
- ترتيب دوري حسب `league` و`season`
- تحويل بيانات API إلى نماذج التطبيق

## تشغيل الاختبار
```bash
flutter pub get
flutter run --dart-define=API_FOOTBALL_KEY=YOUR_KEY
```

**لا ترسل مفتاح API في المحادثة.**

## مثال ترتيب
يمكن لاحقًا ربط:
- Premier League: league=39
- La Liga: league=140
- Champions League: league=2

ويجب اختيار الموسم الصحيح وفق الموسم الحالي لدى مزود البيانات.

## مهم للإنتاج
لا تضع مفتاح API داخل نسخة المتجر. استخدم Backend/Serverless Function لحمايته، ثم اجعل التطبيق يتصل بخادم ركلة.
