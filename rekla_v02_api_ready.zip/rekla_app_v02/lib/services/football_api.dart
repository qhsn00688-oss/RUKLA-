
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/fixture.dart';

class FootballApi {
  static const _base = 'https://v3.football.api-sports.io';
  static const apiKey = String.fromEnvironment('API_FOOTBALL_KEY');

  Future<List<Fixture>> liveFixtures() async {
    if (apiKey.isEmpty) {
      throw Exception('API_FOOTBALL_KEY غير موجود');
    }

    final response = await http.get(
      Uri.parse('$_base/fixtures?live=all'),
      headers: {'x-apisports-key': apiKey},
    );

    if (response.statusCode != 200) {
      throw Exception('فشل الاتصال بمصدر المباريات: ${response.statusCode}');
    }

    final body = jsonDecode(response.body) as Map<String, dynamic>;
    final data = (body['response'] as List<dynamic>? ?? []);
    return data
        .map((e) => Fixture.fromJson(e as Map<String, dynamic>))
        .toList();
  }
}
