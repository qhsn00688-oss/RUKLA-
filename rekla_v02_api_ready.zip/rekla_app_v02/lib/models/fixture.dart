
class Fixture {
  final int id;
  final String home;
  final String away;
  final int homeGoals;
  final int awayGoals;
  final String status;
  final String date;

  const Fixture({
    required this.id,
    required this.home,
    required this.away,
    required this.homeGoals,
    required this.awayGoals,
    required this.status,
    required this.date,
  });

  factory Fixture.fromJson(Map<String, dynamic> json) {
    final teams = json['teams'] ?? {};
    final goals = json['goals'] ?? {};
    final fixture = json['fixture'] ?? {};
    final statusObj = fixture['status'] ?? {};

    return Fixture(
      id: (fixture['id'] ?? 0) as int,
      home: (teams['home']?['name'] ?? 'الفريق المضيف').toString(),
      away: (teams['away']?['name'] ?? 'الفريق الضيف').toString(),
      homeGoals: (goals['home'] ?? 0) as int? ?? 0,
      awayGoals: (goals['away'] ?? 0) as int? ?? 0,
      status: (statusObj['short'] ?? 'NS').toString(),
      date: (fixture['date'] ?? '').toString(),
    );
  }
}
