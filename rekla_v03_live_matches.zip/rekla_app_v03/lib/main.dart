
import 'package:flutter/material.dart';
import 'services/football_api.dart';
import 'models/fixture.dart';

void main() => runApp(const ReklaApp());

class ReklaApp extends StatelessWidget {
  const ReklaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ركلة',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF07131C),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF18E37A),
          brightness: Brightness.dark,
        ),
        fontFamily: 'Arial',
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  final pages = const [
    HomeTab(),
    MatchesTab(),
    LeaguesTab(),
    NewsTab(),
    FavoritesTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('ركلة', style: TextStyle(fontWeight: FontWeight.w800)),
          centerTitle: false,
          backgroundColor: const Color(0xFF07131C),
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
            IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          ],
        ),
        body: pages[index],
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          backgroundColor: const Color(0xFF0B1D28),
          indicatorColor: const Color(0xFF18E37A).withOpacity(.18),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.sports_soccer_outlined), selectedIcon: Icon(Icons.sports_soccer), label: 'المباريات'),
            NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events), label: 'الدوريات'),
            NavigationDestination(icon: Icon(Icons.article_outlined), selectedIcon: Icon(Icons.article), label: 'الأخبار'),
            NavigationDestination(icon: Icon(Icons.star_border), selectedIcon: Icon(Icons.star), label: 'المفضلة'),
          ],
        ),
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          height: 150,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              colors: [Color(0xFF123B2A), Color(0xFF0B202C)],
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
            ),
          ),
          padding: const EdgeInsets.all(20),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('ركلة', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
              SizedBox(height: 8),
              Text('كل كرة القدم في مكان واحد', style: TextStyle(fontSize: 17)),
              Spacer(),
              Text('مباريات • أخبار • نتائج • دوريات', style: TextStyle(color: Color(0xFF18E37A))),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const SectionTitle(title: 'المباريات المباشرة'),
        const MatchCard(home: 'برشلونة', away: 'ريال مدريد', score: '2 - 1', minute: "68'"),
        const SizedBox(height: 20),
        const SectionTitle(title: 'مباريات اليوم'),
        const MatchRow(home: 'مانشستر سيتي', away: 'أرسنال', time: '22:00'),
        const MatchRow(home: 'إنتر ميلان', away: 'ميلان', time: '19:00'),
        const MatchRow(home: 'بايرن ميونخ', away: 'دورتموند', time: '21:45'),
      ],
    );
  }
}

class MatchesTab extends StatefulWidget {
  const MatchesTab({super.key});
  @override
  State<MatchesTab> createState() => _MatchesTabState();
}

class _MatchesTabState extends State<MatchesTab> {
  final api = FootballApi();
  late Future<List<Fixture>> future;

  @override
  void initState() {
    super.initState();
    future = api.liveFixtures();
  }

  void refresh() {
    setState(() => future = api.liveFixtures());
  }

  @override
  Widget build(BuildContext context) => RefreshIndicator(
    onRefresh: () async {
      refresh();
      await future;
    },
    child: FutureBuilder<List<Fixture>>(
      future: future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return ListView(
            padding: const EdgeInsets.all(24),
            children: [
              const Icon(Icons.cloud_off, size: 64),
              const SizedBox(height: 16),
              const Text('تعذر تحميل المباريات المباشرة', textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('${snapshot.error}', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: refresh,
                icon: const Icon(Icons.refresh),
                label: const Text('إعادة المحاولة'),
              ),
            ],
          );
        }

        final games = snapshot.data ?? [];
        if (games.isEmpty) {
          return ListView(
            padding: const EdgeInsets.all(24),
            children: const [
              Icon(Icons.sports_soccer, size: 64),
              SizedBox(height: 16),
              Text('لا توجد مباريات مباشرة الآن',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('اسحب للأسفل للتحديث', textAlign: TextAlign.center),
            ],
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: games.length,
          itemBuilder: (_, i) {
            final g = games[i];
            return Card(
              color: const Color(0xFF0D202B),
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                title: Text('${g.home}  ×  ${g.away}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${g.homeGoals} - ${g.awayGoals}   •   ${g.status}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Color(0xFF18E37A))),
              ),
            );
          },
        );
      },
    ),
  );
}

class LeaguesTab extends StatelessWidget {
  const LeaguesTab({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      SectionTitle(title: 'الدوريات'),
      LeagueCard(name: 'الدوري الإنجليزي الممتاز', icon: '🏴'),
      LeagueCard(name: 'الدوري الإسباني', icon: '🇪🇸'),
      LeagueCard(name: 'الدوري الإيطالي', icon: '🇮🇹'),
      LeagueCard(name: 'الدوري الألماني', icon: '🇩🇪'),
      LeagueCard(name: 'دوري أبطال أوروبا', icon: '🏆'),
    ],
  );
}

class NewsTab extends StatelessWidget {
  const NewsTab({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      SectionTitle(title: 'آخر الأخبار'),
      NewsCard(title: 'أبرز أخبار كرة القدم اليوم', tag: 'أخبار'),
      NewsCard(title: 'استعدادات الفرق للجولة القادمة', tag: 'الدوريات'),
      NewsCard(title: 'أهم الانتقالات والتحديثات', tag: 'انتقالات'),
    ],
  );
}

class FavoritesTab extends StatelessWidget {
  const FavoritesTab({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      SectionTitle(title: 'فرقي المفضلة'),
      FavoriteRow(name: 'برشلونة'),
      FavoriteRow(name: 'ريال مدريد'),
      FavoriteRow(name: 'مانشستر سيتي'),
      FavoriteRow(name: 'ليفربول'),
    ],
  );
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle({required this.title, super.key});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
  );
}

class MatchCard extends StatelessWidget {
  final String home, away, score, minute;
  const MatchCard({required this.home, required this.away, required this.score, required this.minute, super.key});

  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFF102733),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        children: [
          const Text('مباراة مباشرة', style: TextStyle(color: Color(0xFF18E37A))),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Text(home, style: const TextStyle(fontWeight: FontWeight.bold)),
              Column(children: [
                Text(score, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                Text(minute, style: const TextStyle(color: Colors.redAccent)),
              ]),
              Text(away, style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
        ],
      ),
    ),
  );
}

class MatchRow extends StatelessWidget {
  final String home, away, time;
  const MatchRow({required this.home, required this.away, required this.time, super.key});

  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFF0D202B),
    child: ListTile(
      leading: Text(time, style: const TextStyle(color: Color(0xFF18E37A), fontWeight: FontWeight.bold)),
      title: Text('$home  ×  $away', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: const Text('مباراة قادمة', textAlign: TextAlign.center),
    ),
  );
}

class LeagueCard extends StatelessWidget {
  final String name, icon;
  const LeagueCard({required this.name, required this.icon, super.key});

  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFF0D202B),
    child: ListTile(
      leading: Text(icon, style: const TextStyle(fontSize: 28)),
      title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
      trailing: const Icon(Icons.chevron_left),
    ),
  );
}

class NewsCard extends StatelessWidget {
  final String title, tag;
  const NewsCard({required this.title, required this.tag, super.key});

  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFF0D202B),
    child: ListTile(
      leading: const CircleAvatar(
        backgroundColor: Color(0xFF18E37A),
        child: Icon(Icons.sports_soccer, color: Colors.black),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(tag),
    ),
  );
}

class FavoriteRow extends StatelessWidget {
  final String name;
  const FavoriteRow({required this.name, super.key});

  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFF0D202B),
    child: ListTile(
      leading: const Icon(Icons.shield_outlined, color: Color(0xFF18E37A)),
      title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
      trailing: const Icon(Icons.notifications_none),
    ),
  );
}
